1. Team Members:
Shelton Zhou (sz2001)

2. App Description:
This is a voting app for TFT characters. 
You get to vote your favorite character while enjoy some programmer jokes

3. API Links:
https://official-joke-api.appspot.com/jokes/programming/random

4. Youtube Video:
https://youtu.be/zysejgZS5MU

